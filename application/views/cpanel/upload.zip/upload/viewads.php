<?php 
print_r($get_single);
?>