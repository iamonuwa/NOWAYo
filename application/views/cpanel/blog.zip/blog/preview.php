<?php 
// var_dump($edit);



$author['user'] = $this->userutitlities->getUserDetails($opinion['user_id'], NuLL);
$image['url']  = $this->userutitlities->getImageById($opinion['image_id']);
if(!empty($opinion['state_id']))
{
$author['state'] = $this->state_model->get_state($opinion['state_id']);
$state_name = $author['state'][0]['state_name'];
}else
{
	$state_name = "no state";

}


?>

    <script src="<?=base_url('assets/tinymce/tinymce.min')?>"></script>
<script>tinymce.init({selector:'textarea'});</script>
<div class="row">
                <div class="col-lg-12">
  
                
                    <div class="panel panel-default">
                        <div class="panel-body">
                        <img src="<?=base_url('uploads/'.$image['url']['link'])?>" width="200"><br/>
                        <h3 style="color: black">BLOGGER : <?=$author['user']['fullname']?><br/>
                        <small>State: <?= $state_name ?> || views: <?=$opinion['views']?> Visitors</small><br/>
                        blog url:<a href="#"><small><?=strtolower(base_url('isee/presenter/'.$opinion['presenter_id']))?></small>
                        </a></h3>

                        <div class="btn-group">
                        <a href="<?=base_url('cp/presenter_blog')?>" class="btn btn-default">Return Bloggers</a>
                        <a href="<?=base_url('cp/presenter_blog/blog/publish/'.$opinion['id'])?>" class="btn btn-default"><?= empty($opinion['status']) ? 'Publish': 'Disconnect'?></a>
                        <a class="btn btn-default" href="<?=base_url('cp/presenter_blog/blog/edit/'.$opinion['id'])?>">Edit</a>
                        <a class="btn btn-default" target="_blank" href="<?=base_url('isee/presenter/'.strtolower($opinion['presenter_id']))?>">Visit Blog</a>
                        <br/>
                        </div>
                        <div class="container">
                        <h4>Opinion Content</h4>
                        <?php if ($this->uri->segment(3) ==="edit") {?>
                                  <p>
                                  <small style="color: red">Enter Changes and Click Save</small>
                                  <form action="<?=base_url('cp/opinion/edit/save/'.$opinion['id'])?>" method="POST">
                      <!-- <textarea id="wysiwyg" name="comment" cols="45" rows="8" aria-required="true" placeholder="Message"></textarea></p>    -->
            <textarea id="wysiwyg" autofocused="" class="summernote form-control col-md-3" name="content" data-height="200" ><?= $opinion['description']?></textarea></p>

            <div class="btn-group">
	            <input name="save" value="Save" type="submit" class="btn btn-default"/>
            </div>
            </form>
                        <?php }else{ ?>
                        <p><?=$opinion['description']?></p>
                        <?php } ?>
                        <hr/>
                        </div>

                        </div>
                    </div>
	            </div>
</div>
